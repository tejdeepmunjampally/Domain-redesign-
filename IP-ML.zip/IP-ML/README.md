# Domain Forge AI

ML-powered decision system that scores and prioritizes website domains for redesign based on revenue impact and user retention signals.

**Team Paradise · Vignan Institute of Technology and Science**

---

## What it does

1. Ingests raw analytics CSVs (traffic, conversion, LTV, bounce, error rate)
2. Cleans and normalizes session data
3. Segments users into 3 clusters via K-Means (high-value / drop-off / low-value)
4. Predicts conversion probability and churn risk per domain using Random Forest
5. Computes a weighted **Domain Impact Score** for each domain
6. Ranks domains as HIGH / MEDIUM / LOW redesign priority
7. Displays everything in an interactive Streamlit dashboard with a what-if simulator

---

## Quick Start

```bash
git clone <repo-url>
cd domain-forge-ai

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

streamlit run src/dashboard/app.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## Run tests

```bash
PYTHONPATH=. python -m pytest tests/ -v
```

---

## Run individual pipeline stages

```bash
PYTHONPATH=. python src/ingestion/data_loader.py       # load & validate CSV
PYTHONPATH=. python src/preprocessing/cleaner.py       # normalize, encode paths
PYTHONPATH=. python src/analysis/journey.py            # journey reconstruction
PYTHONPATH=. python src/models/clustering.py           # K-Means, saves kmeans.pkl
PYTHONPATH=. python src/models/predictor.py            # RF models, saves .pkl files
PYTHONPATH=. python src/models/scorer.py               # impact score table
PYTHONPATH=. python src/recommendation/ranker.py       # ranked output + simulation
```

---

## Project Structure

```
domain-forge-ai/
├── data/
│   ├── raw/                  # Raw input CSVs
│   ├── processed/            # clean_data.csv (output of cleaner)
│   └── sample/               # sample_data.csv (500 rows, 10 domains)
├── src/
│   ├── ingestion/data_loader.py
│   ├── preprocessing/cleaner.py
│   ├── analysis/journey.py
│   ├── models/
│   │   ├── clustering.py
│   │   ├── predictor.py
│   │   └── scorer.py
│   ├── recommendation/ranker.py
│   └── dashboard/app.py
├── models/saved/             # kmeans.pkl, rf_*.pkl
├── tests/
│   ├── test_cleaner.py       # 17 tests
│   ├── test_models.py        # 18 tests
│   └── test_scorer.py        # 27 tests
├── config.yaml               # weights, thresholds, clustering params
├── requirements.txt
└── .gitlab-ci.yml
```

---

## Configuration

Edit `config.yaml` to tune scoring weights and priority thresholds without touching code:

```yaml
impact_score:
  weights:
    traffic: 0.2
    conversion_rate: 0.35
    ltv: 0.25
    churn_risk: 0.1
    error_rate: 0.1

priority_thresholds:
  high: 0.7
  medium: 0.4
```

---

## Impact Score Formula

```
score = 0.20 * traffic
      + 0.35 * conversion_rate
      + 0.25 * ltv
      - 0.10 * churn_risk
      - 0.10 * error_rate
```

All inputs are normalized to [0, 1]. Score is clamped to [0, 1].

---

## Sample Output

| Domain | Impact Score | Priority |
|---|---|---|
| dashboard.example.com | 0.556 | MEDIUM |
| api.example.com | 0.504 | MEDIUM |
| login.example.com | 0.503 | MEDIUM |
| shop.example.com | 0.384 | LOW |
| old.example.com | 0.000 | LOW |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Dashboard | Streamlit |
| ML Models | scikit-learn (Random Forest, K-Means) |
| Data | Pandas, NumPy |
| Visualization | Plotly |
| Config | PyYAML |
| CI/CD | GitLab CI/CD |
| Language | Python 3.10+ |

---

> *Built Domain Forge AI — an ML pipeline using K-Means and Random Forest to score and prioritize website domains for redesign based on business impact.*
