"""test_cleaner.py — Unit tests for src/preprocessing/cleaner.py"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Allow running from repo root without installing the package
sys.path.insert(0, str(Path(__file__).parents[1]))

from src.preprocessing.cleaner import (
    clean,
    drop_nulls,
    encode_click_path,
    normalize_numeric,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def sample_df() -> pd.DataFrame:
    """Minimal valid DataFrame matching the project schema."""
    return pd.DataFrame(
        {
            "domain": ["shop.example.com", "blog.example.com", "docs.example.com"],
            "session_id": ["sess_001", "sess_002", "sess_003"],
            "traffic": [0.8, 0.4, 0.1],
            "conversion_rate": [0.25, 0.12, 0.40],
            "bounce_rate": [0.30, 0.55, 0.20],
            "ltv": [180.0, 40.0, 60.0],
            "error_rate": [0.03, 0.01, 0.02],
            "click_path": [
                "home>shop>checkout",
                "home>blog>article",
                "home>docs>guide",
            ],
        }
    )


# ---------------------------------------------------------------------------
# drop_nulls
# ---------------------------------------------------------------------------

class TestDropNulls:
    def test_removes_null_rows(self, sample_df: pd.DataFrame) -> None:
        df_with_null = sample_df.copy()
        df_with_null.loc[1, "traffic"] = np.nan
        result = drop_nulls(df_with_null)
        assert len(result) == 2
        assert result["session_id"].tolist() == ["sess_001", "sess_003"]

    def test_no_nulls_unchanged_length(self, sample_df: pd.DataFrame) -> None:
        result = drop_nulls(sample_df)
        assert len(result) == len(sample_df)

    def test_returns_new_dataframe(self, sample_df: pd.DataFrame) -> None:
        result = drop_nulls(sample_df)
        assert result is not sample_df

    def test_index_reset_after_drop(self, sample_df: pd.DataFrame) -> None:
        df_with_null = sample_df.copy()
        df_with_null.loc[0, "ltv"] = np.nan
        result = drop_nulls(df_with_null)
        assert result.index.tolist() == list(range(len(result)))


# ---------------------------------------------------------------------------
# normalize_numeric
# ---------------------------------------------------------------------------

class TestNormalizeNumeric:
    def test_values_in_zero_one(self, sample_df: pd.DataFrame) -> None:
        result = normalize_numeric(sample_df)
        for col in ["traffic", "conversion_rate", "bounce_rate", "ltv", "error_rate"]:
            assert result[col].min() >= 0.0 - 1e-9
            assert result[col].max() <= 1.0 + 1e-9

    def test_non_numeric_columns_untouched(self, sample_df: pd.DataFrame) -> None:
        result = normalize_numeric(sample_df)
        assert result["domain"].tolist() == sample_df["domain"].tolist()
        assert result["click_path"].tolist() == sample_df["click_path"].tolist()

    def test_returns_new_dataframe(self, sample_df: pd.DataFrame) -> None:
        result = normalize_numeric(sample_df)
        assert result is not sample_df

    def test_single_row_no_error(self) -> None:
        single = pd.DataFrame(
            {
                "domain": ["x.com"],
                "session_id": ["s1"],
                "traffic": [0.5],
                "conversion_rate": [0.3],
                "bounce_rate": [0.4],
                "ltv": [100.0],
                "error_rate": [0.02],
                "click_path": ["home>shop"],
            }
        )
        result = normalize_numeric(single)
        # With a single row every normalized value must be 0.0
        for col in ["traffic", "conversion_rate", "bounce_rate", "ltv", "error_rate"]:
            assert result[col].iloc[0] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# encode_click_path
# ---------------------------------------------------------------------------

class TestEncodeClickPath:
    def test_path_becomes_list(self, sample_df: pd.DataFrame) -> None:
        result = encode_click_path(sample_df)
        for path in result["click_path"]:
            assert isinstance(path, list)

    def test_correct_tokenization(self, sample_df: pd.DataFrame) -> None:
        result = encode_click_path(sample_df)
        assert result["click_path"].iloc[0] == ["home", "shop", "checkout"]

    def test_original_string_preserved(self, sample_df: pd.DataFrame) -> None:
        result = encode_click_path(sample_df)
        assert "click_path_str" in result.columns
        assert result["click_path_str"].iloc[0] == "home>shop>checkout"

    def test_returns_new_dataframe(self, sample_df: pd.DataFrame) -> None:
        result = encode_click_path(sample_df)
        assert result is not sample_df


# ---------------------------------------------------------------------------
# clean (full pipeline)
# ---------------------------------------------------------------------------

class TestCleanPipeline:
    def test_output_shape_unchanged_when_no_nulls(self, sample_df: pd.DataFrame) -> None:
        result = clean(sample_df)
        assert len(result) == len(sample_df)

    def test_numeric_cols_normalized(self, sample_df: pd.DataFrame) -> None:
        result = clean(sample_df)
        for col in ["traffic", "conversion_rate", "bounce_rate", "ltv", "error_rate"]:
            assert result[col].min() >= 0.0 - 1e-9
            assert result[col].max() <= 1.0 + 1e-9

    def test_click_path_is_list(self, sample_df: pd.DataFrame) -> None:
        result = clean(sample_df)
        for path in result["click_path"]:
            assert isinstance(path, list)

    def test_null_rows_removed(self, sample_df: pd.DataFrame) -> None:
        df_with_null = sample_df.copy()
        df_with_null.loc[2, "bounce_rate"] = np.nan
        result = clean(df_with_null)
        assert len(result) == 2

    def test_returns_new_dataframe(self, sample_df: pd.DataFrame) -> None:
        result = clean(sample_df)
        assert result is not sample_df
