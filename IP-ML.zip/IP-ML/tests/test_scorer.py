"""test_scorer.py — Unit tests for scorer.py and ranker.py."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.models.scorer import (
    aggregate_by_domain,
    compute_impact_scores,
    DEFAULT_WEIGHTS,
    _derive_churn_risk_if_missing,
)
from src.recommendation.ranker import (
    assign_priority,
    simulate_redesign,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def domain_df() -> pd.DataFrame:
    """Minimal per-domain aggregated DataFrame (already one row per domain)."""
    return pd.DataFrame(
        {
            "domain": [
                "shop.example.com",
                "blog.example.com",
                "old.example.com",
            ],
            "traffic": [0.85, 0.50, 0.10],
            "conversion_rate": [0.70, 0.30, 0.05],
            "bounce_rate": [0.20, 0.55, 0.80],
            "ltv": [0.80, 0.30, 0.05],
            "error_rate": [0.02, 0.05, 0.15],
            "churn_risk": [0.0, 0.5, 1.0],
        }
    )


@pytest.fixture()
def row_df() -> pd.DataFrame:
    """Row-level DataFrame (multiple sessions per domain) for aggregate tests."""
    return pd.DataFrame(
        {
            "domain": ["a.com", "a.com", "b.com", "b.com"],
            "session_id": ["s1", "s2", "s3", "s4"],
            "traffic": [0.8, 0.6, 0.3, 0.4],
            "conversion_rate": [0.5, 0.7, 0.2, 0.1],
            "bounce_rate": [0.2, 0.3, 0.6, 0.7],
            "ltv": [0.9, 0.8, 0.2, 0.3],
            "error_rate": [0.01, 0.02, 0.08, 0.09],
            "churn_risk": [0.0, 0.0, 1.0, 1.0],
        }
    )


THRESHOLDS = {"high": 0.7, "medium": 0.4}


# ---------------------------------------------------------------------------
# scorer — aggregate_by_domain
# ---------------------------------------------------------------------------

class TestAggregateByDomain:
    def test_one_row_per_domain(self, row_df: pd.DataFrame) -> None:
        result = aggregate_by_domain(row_df)
        assert len(result) == 2

    def test_means_are_correct(self, row_df: pd.DataFrame) -> None:
        result = aggregate_by_domain(row_df)
        a_row = result[result["domain"] == "a.com"].iloc[0]
        assert a_row["traffic"] == pytest.approx(0.7)
        assert a_row["conversion_rate"] == pytest.approx(0.6)

    def test_returns_new_dataframe(self, row_df: pd.DataFrame) -> None:
        result = aggregate_by_domain(row_df)
        assert result is not row_df

    def test_domain_column_present(self, row_df: pd.DataFrame) -> None:
        result = aggregate_by_domain(row_df)
        assert "domain" in result.columns


# ---------------------------------------------------------------------------
# scorer — _derive_churn_risk_if_missing
# ---------------------------------------------------------------------------

class TestDeriveChurnRiskIfMissing:
    def test_adds_column_when_absent(self) -> None:
        df = pd.DataFrame({"bounce_rate": [0.8], "conversion_rate": [0.1]})
        result = _derive_churn_risk_if_missing(df)
        assert "churn_risk" in result.columns

    def test_does_not_overwrite_existing(self, domain_df: pd.DataFrame) -> None:
        original_values = domain_df["churn_risk"].tolist()
        result = _derive_churn_risk_if_missing(domain_df)
        assert result["churn_risk"].tolist() == original_values


# ---------------------------------------------------------------------------
# scorer — compute_impact_scores
# ---------------------------------------------------------------------------

class TestComputeImpactScores:
    def test_impact_score_column_present(self, domain_df: pd.DataFrame) -> None:
        result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        assert "impact_score" in result.columns

    def test_scores_in_zero_one(self, domain_df: pd.DataFrame) -> None:
        result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        assert result["impact_score"].between(0.0, 1.0).all()

    def test_sorted_descending(self, domain_df: pd.DataFrame) -> None:
        result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        scores = result["impact_score"].tolist()
        assert scores == sorted(scores, reverse=True)

    def test_high_value_domain_scores_higher(self, domain_df: pd.DataFrame) -> None:
        result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        shop_score = result.loc[result["domain"] == "shop.example.com", "impact_score"].iloc[0]
        old_score = result.loc[result["domain"] == "old.example.com", "impact_score"].iloc[0]
        assert shop_score > old_score

    def test_returns_new_dataframe(self, domain_df: pd.DataFrame) -> None:
        result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        assert result is not domain_df

    def test_custom_weights_change_scores(self, domain_df: pd.DataFrame) -> None:
        default_result = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        custom_weights = {**DEFAULT_WEIGHTS, "error_rate": 0.5}
        custom_result = compute_impact_scores(domain_df, custom_weights)
        # With error_rate heavily penalized, scores should differ
        assert not default_result["impact_score"].equals(custom_result["impact_score"])


# ---------------------------------------------------------------------------
# ranker — assign_priority
# ---------------------------------------------------------------------------

class TestAssignPriority:
    def test_priority_column_added(self, domain_df: pd.DataFrame) -> None:
        scored = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        result = assign_priority(scored, THRESHOLDS)
        assert "priority" in result.columns

    def test_valid_priority_labels(self, domain_df: pd.DataFrame) -> None:
        scored = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        result = assign_priority(scored, THRESHOLDS)
        assert set(result["priority"]).issubset({"HIGH", "MEDIUM", "LOW"})

    def test_high_score_gets_high_priority(self) -> None:
        df = pd.DataFrame({"domain": ["x.com"], "impact_score": [0.85]})
        result = assign_priority(df, THRESHOLDS)
        assert result["priority"].iloc[0] == "HIGH"

    def test_medium_score_gets_medium_priority(self) -> None:
        df = pd.DataFrame({"domain": ["x.com"], "impact_score": [0.55]})
        result = assign_priority(df, THRESHOLDS)
        assert result["priority"].iloc[0] == "MEDIUM"

    def test_low_score_gets_low_priority(self) -> None:
        df = pd.DataFrame({"domain": ["x.com"], "impact_score": [0.20]})
        result = assign_priority(df, THRESHOLDS)
        assert result["priority"].iloc[0] == "LOW"

    def test_exact_high_threshold_is_high(self) -> None:
        df = pd.DataFrame({"domain": ["x.com"], "impact_score": [0.7]})
        result = assign_priority(df, THRESHOLDS)
        assert result["priority"].iloc[0] == "HIGH"

    def test_exact_medium_threshold_is_medium(self) -> None:
        df = pd.DataFrame({"domain": ["x.com"], "impact_score": [0.4]})
        result = assign_priority(df, THRESHOLDS)
        assert result["priority"].iloc[0] == "MEDIUM"

    def test_returns_new_dataframe(self, domain_df: pd.DataFrame) -> None:
        scored = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        result = assign_priority(scored, THRESHOLDS)
        assert result is not scored


# ---------------------------------------------------------------------------
# ranker — simulate_redesign
# ---------------------------------------------------------------------------

class TestSimulateRedesign:
    @pytest.fixture()
    def ranked_df(self, domain_df: pd.DataFrame) -> pd.DataFrame:
        scored = compute_impact_scores(domain_df, DEFAULT_WEIGHTS)
        return assign_priority(scored, THRESHOLDS)

    def test_returns_redesign_result(self, ranked_df: pd.DataFrame) -> None:
        result = simulate_redesign(
            ranked_df, "shop.example.com", DEFAULT_WEIGHTS,
            delta_conversion=0.05
        )
        assert result.domain == "shop.example.com"

    def test_positive_delta_increases_score(self, ranked_df: pd.DataFrame) -> None:
        result = simulate_redesign(
            ranked_df, "old.example.com", DEFAULT_WEIGHTS,
            delta_conversion=0.10
        )
        assert result.new_score >= result.original_score

    def test_negative_error_delta_increases_score(self, ranked_df: pd.DataFrame) -> None:
        result = simulate_redesign(
            ranked_df, "blog.example.com", DEFAULT_WEIGHTS,
            delta_error=-0.05
        )
        assert result.new_score >= result.original_score

    def test_no_delta_returns_same_score(self, ranked_df: pd.DataFrame) -> None:
        result = simulate_redesign(
            ranked_df, "shop.example.com", DEFAULT_WEIGHTS
        )
        assert result.score_delta == pytest.approx(0.0, abs=1e-6)

    def test_revenue_delta_positive_for_positive_conversion(
        self, ranked_df: pd.DataFrame
    ) -> None:
        result = simulate_redesign(
            ranked_df, "shop.example.com", DEFAULT_WEIGHTS,
            delta_conversion=0.10, avg_ltv=200.0
        )
        assert result.revenue_delta > 0

    def test_score_clamped_to_one(self, ranked_df: pd.DataFrame) -> None:
        result = simulate_redesign(
            ranked_df, "shop.example.com", DEFAULT_WEIGHTS,
            delta_conversion=999.0
        )
        assert result.new_score <= 1.0

    def test_unknown_domain_raises(self, ranked_df: pd.DataFrame) -> None:
        with pytest.raises(ValueError, match="not found"):
            simulate_redesign(ranked_df, "ghost.com", DEFAULT_WEIGHTS)
