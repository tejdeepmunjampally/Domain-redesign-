"""test_models.py — Unit tests for clustering.py and predictor.py."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.models.clustering import (
    assign_cluster_labels,
    fit_kmeans,
    CLUSTER_LABELS,
    FEATURE_COLUMNS,
)
from src.models.predictor import (
    _derive_churn_risk,
    _encode_cluster_labels,
    train_churn_classifier,
    train_conversion_regressor,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def base_df() -> pd.DataFrame:
    """Small normalized DataFrame for fast model tests."""
    np.random.seed(42)
    n = 60  # enough for train/test split
    return pd.DataFrame(
        {
            "domain": np.random.choice(["a.com", "b.com", "c.com"], n),
            "session_id": [f"s{i}" for i in range(n)],
            "traffic": np.random.uniform(0, 1, n),
            "conversion_rate": np.random.uniform(0, 1, n),
            "bounce_rate": np.random.uniform(0, 1, n),
            "ltv": np.random.uniform(0, 1, n),
            "error_rate": np.random.uniform(0, 1, n),
            "click_path": ["home>shop>checkout"] * n,
            "click_path_str": ["home>shop>checkout"] * n,
        }
    )


@pytest.fixture()
def clustered_df(base_df: pd.DataFrame) -> pd.DataFrame:
    """base_df with cluster_label column appended."""
    model, raw_labels = fit_kmeans(base_df, k=3, random_state=42)
    return assign_cluster_labels(base_df, model, raw_labels)


# ---------------------------------------------------------------------------
# clustering.py
# ---------------------------------------------------------------------------

class TestFitKMeans:
    def test_returns_model_and_labels(self, base_df: pd.DataFrame) -> None:
        model, labels = fit_kmeans(base_df, k=3, random_state=42)
        assert labels.shape == (len(base_df),)

    def test_label_count_equals_k(self, base_df: pd.DataFrame) -> None:
        model, labels = fit_kmeans(base_df, k=3, random_state=42)
        assert len(set(labels)) == 3

    def test_different_k(self, base_df: pd.DataFrame) -> None:
        model, labels = fit_kmeans(base_df, k=2, random_state=42)
        assert len(set(labels)) == 2


class TestAssignClusterLabels:
    def test_column_appended(self, base_df: pd.DataFrame) -> None:
        model, raw = fit_kmeans(base_df, k=3, random_state=42)
        result = assign_cluster_labels(base_df, model, raw)
        assert "cluster_label" in result.columns

    def test_labels_are_valid(self, base_df: pd.DataFrame) -> None:
        model, raw = fit_kmeans(base_df, k=3, random_state=42)
        result = assign_cluster_labels(base_df, model, raw)
        assert set(result["cluster_label"]).issubset(set(CLUSTER_LABELS))

    def test_returns_new_dataframe(self, base_df: pd.DataFrame) -> None:
        model, raw = fit_kmeans(base_df, k=3, random_state=42)
        result = assign_cluster_labels(base_df, model, raw)
        assert result is not base_df

    def test_row_count_unchanged(self, base_df: pd.DataFrame) -> None:
        model, raw = fit_kmeans(base_df, k=3, random_state=42)
        result = assign_cluster_labels(base_df, model, raw)
        assert len(result) == len(base_df)


# ---------------------------------------------------------------------------
# predictor.py — helpers
# ---------------------------------------------------------------------------

class TestEncodeClusterLabels:
    def test_column_added(self, clustered_df: pd.DataFrame) -> None:
        result = _encode_cluster_labels(clustered_df)
        assert "cluster_label_enc" in result.columns

    def test_encoded_values_are_integers(self, clustered_df: pd.DataFrame) -> None:
        result = _encode_cluster_labels(clustered_df)
        assert result["cluster_label_enc"].dtype in (np.int32, np.int64, int)

    def test_returns_new_dataframe(self, clustered_df: pd.DataFrame) -> None:
        result = _encode_cluster_labels(clustered_df)
        assert result is not clustered_df


class TestDeriveChurnRisk:
    def test_column_added(self, clustered_df: pd.DataFrame) -> None:
        result = _derive_churn_risk(clustered_df)
        assert "churn_risk" in result.columns

    def test_binary_values(self, clustered_df: pd.DataFrame) -> None:
        result = _derive_churn_risk(clustered_df)
        assert set(result["churn_risk"].unique()).issubset({0, 1})

    def test_high_bounce_low_conv_is_churned(self) -> None:
        df = pd.DataFrame(
            {
                "bounce_rate": [0.9],
                "conversion_rate": [0.1],
            }
        )
        result = _derive_churn_risk(df)
        assert result["churn_risk"].iloc[0] == 1

    def test_low_bounce_high_conv_is_not_churned(self) -> None:
        df = pd.DataFrame(
            {
                "bounce_rate": [0.1],
                "conversion_rate": [0.8],
            }
        )
        result = _derive_churn_risk(df)
        assert result["churn_risk"].iloc[0] == 0


# ---------------------------------------------------------------------------
# predictor.py — model training
# ---------------------------------------------------------------------------

class TestTrainConversionRegressor:
    def test_model_trains_without_error(self, clustered_df: pd.DataFrame) -> None:
        model = train_conversion_regressor(clustered_df, random_state=42)
        assert model is not None

    def test_model_can_predict(self, clustered_df: pd.DataFrame) -> None:
        from src.models.predictor import _encode_cluster_labels, RF_FEATURES
        model = train_conversion_regressor(clustered_df, random_state=42)
        encoded = _encode_cluster_labels(clustered_df)
        preds = model.predict(encoded[RF_FEATURES].values[:5])
        assert preds.shape == (5,)
        assert np.all(preds >= 0)


class TestTrainChurnClassifier:
    def test_model_trains_without_error(self, clustered_df: pd.DataFrame) -> None:
        model = train_churn_classifier(clustered_df, random_state=42)
        assert model is not None

    def test_predictions_are_binary(self, clustered_df: pd.DataFrame) -> None:
        from src.models.predictor import _encode_cluster_labels, RF_FEATURES
        model = train_churn_classifier(clustered_df, random_state=42)
        encoded = _encode_cluster_labels(clustered_df)
        preds = model.predict(encoded[RF_FEATURES].values[:5])
        assert set(preds).issubset({0, 1})
