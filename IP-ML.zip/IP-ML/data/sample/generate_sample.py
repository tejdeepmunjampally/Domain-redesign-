"""Script to generate sample_data.csv with realistic fake data."""
import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)

DOMAINS = [
    "shop.example.com",
    "blog.example.com",
    "docs.example.com",
    "old.example.com",
    "api.example.com",
    "support.example.com",
    "pricing.example.com",
    "careers.example.com",
    "login.example.com",
    "dashboard.example.com",
]

CLICK_PATH_TEMPLATES = [
    "home>shop>checkout",
    "home>blog>article",
    "home>docs>guide",
    "home>pricing>signup",
    "home>login>dashboard",
    "home>support>ticket",
    "home>careers>apply",
    "home>shop>drop",
    "home>blog>drop",
    "home>docs>drop",
]

domain_profiles = {
    "shop.example.com":      dict(traffic_mu=0.85, conv_mu=0.25, bounce_mu=0.30, ltv_mu=180, err_mu=0.03),
    "blog.example.com":      dict(traffic_mu=0.60, conv_mu=0.12, bounce_mu=0.55, ltv_mu=40,  err_mu=0.01),
    "docs.example.com":      dict(traffic_mu=0.35, conv_mu=0.40, bounce_mu=0.20, ltv_mu=60,  err_mu=0.02),
    "old.example.com":       dict(traffic_mu=0.15, conv_mu=0.05, bounce_mu=0.80, ltv_mu=10,  err_mu=0.12),
    "api.example.com":       dict(traffic_mu=0.70, conv_mu=0.60, bounce_mu=0.10, ltv_mu=200, err_mu=0.05),
    "support.example.com":   dict(traffic_mu=0.45, conv_mu=0.18, bounce_mu=0.40, ltv_mu=30,  err_mu=0.04),
    "pricing.example.com":   dict(traffic_mu=0.55, conv_mu=0.35, bounce_mu=0.35, ltv_mu=150, err_mu=0.02),
    "careers.example.com":   dict(traffic_mu=0.20, conv_mu=0.08, bounce_mu=0.60, ltv_mu=5,   err_mu=0.01),
    "login.example.com":     dict(traffic_mu=0.80, conv_mu=0.70, bounce_mu=0.15, ltv_mu=120, err_mu=0.06),
    "dashboard.example.com": dict(traffic_mu=0.75, conv_mu=0.65, bounce_mu=0.12, ltv_mu=220, err_mu=0.04),
}

rows = []
session_counter = 1
rows_per_domain = 50

for domain in DOMAINS:
    p = domain_profiles[domain]
    for _ in range(rows_per_domain):
        session_id = f"sess_{session_counter:04d}"
        session_counter += 1
        traffic = float(np.clip(np.random.normal(p["traffic_mu"], 0.10), 0.01, 1.0))
        conversion_rate = float(np.clip(np.random.normal(p["conv_mu"], 0.05), 0.0, 1.0))
        bounce_rate = float(np.clip(np.random.normal(p["bounce_mu"], 0.08), 0.0, 1.0))
        ltv = float(np.clip(np.random.normal(p["ltv_mu"], p["ltv_mu"] * 0.2), 0.0, 500.0))
        error_rate = float(np.clip(np.random.normal(p["err_mu"], 0.01), 0.0, 0.5))
        click_path = np.random.choice(CLICK_PATH_TEMPLATES)
        rows.append({
            "domain": domain,
            "session_id": session_id,
            "traffic": round(traffic, 4),
            "conversion_rate": round(conversion_rate, 4),
            "bounce_rate": round(bounce_rate, 4),
            "ltv": round(ltv, 2),
            "error_rate": round(error_rate, 4),
            "click_path": click_path,
        })

df = pd.DataFrame(rows)
out_path = Path(__file__).parent / "sample_data.csv"
df.to_csv(out_path, index=False)
print(f"Generated {len(df)} rows -> {out_path}")
print(df.head())
