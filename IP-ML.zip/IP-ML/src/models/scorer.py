"""scorer.py — Domain Impact Score engine.

Aggregates per-domain metrics from the row-level DataFrame and computes
a weighted Impact Score for each domain:

    score = w1*traffic + w2*conversion_rate + w3*ltv
            - w4*churn_risk - w5*error_rate

All weights and thresholds are read from config.yaml so they remain
configurable without touching source code.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import yaml


DEFAULT_WEIGHTS: dict[str, float] = {
    "traffic": 0.2,
    "conversion_rate": 0.35,
    "ltv": 0.25,
    "churn_risk": 0.1,
    "error_rate": 0.1,
}


def load_weights(config_path: Path) -> dict[str, float]:
    """Read impact score weights from config.yaml.

    Args:
        config_path: Path to the project config.yaml file.

    Returns:
        Dict mapping feature name -> weight float.
    """
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    return cfg["impact_score"]["weights"]


def aggregate_by_domain(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate row-level data to one row per domain.

    Numeric columns are averaged; churn_risk (if present) is averaged
    to produce a per-domain churn probability.

    Args:
        df: Cleaned, clustered DataFrame at session-row granularity.

    Returns:
        New DataFrame with one row per domain and mean feature values.
    """
    agg_cols = ["traffic", "conversion_rate", "bounce_rate", "ltv", "error_rate"]
    if "churn_risk" in df.columns:
        agg_cols.append("churn_risk")

    present = [c for c in agg_cols if c in df.columns]
    aggregated = df.groupby("domain")[present].mean().reset_index()
    return aggregated


def _derive_churn_risk_if_missing(df: pd.DataFrame) -> pd.DataFrame:
    """Add churn_risk column if it was not produced upstream.

    Uses the same heuristic as predictor.py:
    churn_risk = 1 when bounce_rate >= 0.5 AND conversion_rate <= 0.3.

    Args:
        df: Aggregated per-domain DataFrame.

    Returns:
        DataFrame with churn_risk column guaranteed to be present.
    """
    if "churn_risk" in df.columns:
        return df
    result = df.copy()
    result["churn_risk"] = (
        (result["bounce_rate"] >= 0.5) & (result["conversion_rate"] <= 0.3)
    ).astype(float)
    return result


def compute_impact_scores(
    domain_df: pd.DataFrame,
    weights: dict[str, float],
) -> pd.DataFrame:
    """Apply the weighted formula to compute Domain Impact Scores.

    score = w_traffic * traffic
          + w_conversion_rate * conversion_rate
          + w_ltv * ltv
          - w_churn_risk * churn_risk
          - w_error_rate * error_rate

    Args:
        domain_df: Per-domain aggregated DataFrame (output of aggregate_by_domain).
        weights: Weight dict from load_weights or DEFAULT_WEIGHTS.

    Returns:
        New DataFrame with `impact_score` column appended, sorted descending.
    """
    result = _derive_churn_risk_if_missing(domain_df)
    result = result.copy()

    result["impact_score"] = (
        weights.get("traffic", 0.0) * result["traffic"]
        + weights.get("conversion_rate", 0.0) * result["conversion_rate"]
        + weights.get("ltv", 0.0) * result["ltv"]
        - weights.get("churn_risk", 0.0) * result["churn_risk"]
        - weights.get("error_rate", 0.0) * result["error_rate"]
    )

    # Clamp to [0, 1]
    result["impact_score"] = result["impact_score"].clip(0.0, 1.0)
    return result.sort_values("impact_score", ascending=False).reset_index(drop=True)


def score_domains(
    df: pd.DataFrame,
    config_path: Path,
) -> pd.DataFrame:
    """Full scoring pipeline: aggregate -> weight -> score.

    Args:
        df: Row-level cleaned DataFrame (may or may not have churn_risk).
        config_path: Path to config.yaml.

    Returns:
        Per-domain DataFrame with impact_score column, sorted descending.
    """
    weights = load_weights(config_path)
    domain_df = aggregate_by_domain(df)
    return compute_impact_scores(domain_df, weights)


if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate
    from src.preprocessing.cleaner import clean
    from src.models.clustering import run_clustering
    from src.models.predictor import _encode_cluster_labels, _derive_churn_risk

    root = Path(__file__).parents[2]

    raw_df = load_and_validate(root / "data" / "sample" / "sample_data.csv")
    clean_df = clean(raw_df)
    clustered_df = run_clustering(clean_df, config_path=root / "config.yaml")
    clustered_df = _derive_churn_risk(clustered_df)

    scored_df = score_domains(clustered_df, config_path=root / "config.yaml")

    print("Domain Impact Scores:")
    print(
        scored_df[["domain", "traffic", "conversion_rate", "ltv", "churn_risk", "impact_score"]]
        .to_string(index=False)
    )
