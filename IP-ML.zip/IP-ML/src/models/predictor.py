"""predictor.py — Random Forest and LSTM predictive models.

Random Forest:
    - Features: traffic, bounce_rate, error_rate, cluster_label (encoded)
    - Target 1: conversion_probability (regression)
    - Target 2: churn_risk (binary classification — high bounce + low conversion)
    - Saves model to models/saved/rf_model.pkl

LSTM (stretch goal):
    - Input: encoded click_path sequences (padded integer sequences)
    - Output: predicted future conversion score
    - Saves model to models/saved/lstm_model.h5
"""
from __future__ import annotations

import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

RF_FEATURES: list[str] = ["traffic", "bounce_rate", "error_rate", "cluster_label_enc"]


def _encode_cluster_labels(df: pd.DataFrame) -> pd.DataFrame:
    """Encode the cluster_label column as an integer for model input.

    Args:
        df: DataFrame containing a `cluster_label` string column.

    Returns:
        New DataFrame with `cluster_label_enc` integer column appended.
    """
    result = df.copy()
    le = LabelEncoder()
    result["cluster_label_enc"] = le.fit_transform(result["cluster_label"].astype(str))
    return result


def _derive_churn_risk(df: pd.DataFrame) -> pd.DataFrame:
    """Derive a binary churn_risk label from bounce_rate and conversion_rate.

    A row is labeled high-churn (1) when bounce_rate >= 0.5 AND
    conversion_rate <= 0.3 (both already normalized to [0, 1]).

    Args:
        df: Cleaned DataFrame with normalized numeric columns.

    Returns:
        New DataFrame with `churn_risk` binary column appended.
    """
    result = df.copy()
    result["churn_risk"] = (
        (result["bounce_rate"] >= 0.5) & (result["conversion_rate"] <= 0.3)
    ).astype(int)
    return result


def _save_artifact(obj: Any, path: Path) -> None:
    """Pickle an object to disk, creating parent dirs as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    print(f"[predictor] Saved -> {path}")


def load_artifact(path: Path) -> Any:
    """Load a pickled model artifact from disk.

    Args:
        path: Path to the .pkl file.

    Returns:
        Deserialized Python object.
    """
    with open(path, "rb") as f:
        return pickle.load(f)


# ---------------------------------------------------------------------------
# Random Forest — Regression (conversion_probability)
# ---------------------------------------------------------------------------

def train_conversion_regressor(
    df: pd.DataFrame,
    save_path: Path | None = None,
    random_state: int = 42,
) -> RandomForestRegressor:
    """Train a Random Forest regressor to predict conversion_probability.

    Uses conversion_rate (normalized) as the regression target since it is
    the closest proxy for conversion probability available in the dataset.

    Args:
        df: Clustered, cleaned DataFrame.
        save_path: Optional path to persist the model.
        random_state: Seed for reproducibility.

    Returns:
        Fitted RandomForestRegressor.
    """
    df = _encode_cluster_labels(df)
    X = df[RF_FEATURES].values
    y = df["conversion_rate"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state
    )
    model = RandomForestRegressor(n_estimators=100, random_state=random_state)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    print(f"[predictor] Conversion Regressor RMSE: {rmse:.4f}")

    if save_path:
        _save_artifact(model, save_path)

    return model


# ---------------------------------------------------------------------------
# Random Forest — Classification (churn_risk)
# ---------------------------------------------------------------------------

def train_churn_classifier(
    df: pd.DataFrame,
    save_path: Path | None = None,
    random_state: int = 42,
) -> RandomForestClassifier:
    """Train a Random Forest classifier to predict churn risk.

    Args:
        df: Clustered, cleaned DataFrame.
        save_path: Optional path to persist the model.
        random_state: Seed for reproducibility.

    Returns:
        Fitted RandomForestClassifier.
    """
    df = _encode_cluster_labels(df)
    df = _derive_churn_risk(df)

    X = df[RF_FEATURES].values
    y = df["churn_risk"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state
    )
    model = RandomForestClassifier(n_estimators=100, random_state=random_state)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print(f"[predictor] Churn Classifier Accuracy: {acc:.4f}")

    if save_path:
        _save_artifact(model, save_path)

    return model


# ---------------------------------------------------------------------------
# LSTM — Sequential conversion score prediction
# ---------------------------------------------------------------------------

def _build_sequence_dataset(
    df: pd.DataFrame,
    max_len: int = 10,
) -> tuple[np.ndarray, np.ndarray, dict[str, int]]:
    """Encode click_path lists as padded integer sequences.

    Args:
        df: DataFrame where `click_path` is a list of step tokens.
        max_len: Maximum sequence length (shorter paths are zero-padded).

    Returns:
        Tuple of (X padded sequences, y conversion_rate targets, vocab dict).
    """
    from tensorflow.keras.preprocessing.sequence import pad_sequences  # type: ignore

    # Build vocabulary from all unique step tokens
    all_steps: list[str] = []
    for path in df["click_path"]:
        steps = path if isinstance(path, list) else str(path).split(">")
        all_steps.extend(steps)
    vocab = {token: idx + 1 for idx, token in enumerate(sorted(set(all_steps)))}

    sequences: list[list[int]] = []
    for path in df["click_path"]:
        steps = path if isinstance(path, list) else str(path).split(">")
        sequences.append([vocab.get(s, 0) for s in steps])

    X = pad_sequences(sequences, maxlen=max_len, padding="post", truncating="post")
    y = df["conversion_rate"].values
    return X, y, vocab


def train_lstm(
    df: pd.DataFrame,
    save_path: Path | None = None,
    max_len: int = 10,
    epochs: int = 5,
    random_state: int = 42,
) -> Any:
    """Train a lightweight LSTM to predict conversion score from click paths.

    Args:
        df: Cleaned, clustered DataFrame. `click_path` must be list of tokens.
        save_path: Optional path to save the Keras model (.h5 or SavedModel dir).
        max_len: Sequence padding length.
        epochs: Training epochs.
        random_state: NumPy seed for reproducibility.

    Returns:
        Fitted Keras Sequential model.
    """
    import tensorflow as tf
    from tensorflow import keras

    np.random.seed(random_state)
    tf.random.set_seed(random_state)

    X, y, vocab = _build_sequence_dataset(df, max_len=max_len)
    vocab_size = len(vocab) + 1

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state
    )

    model = keras.Sequential([
        keras.layers.Embedding(input_dim=vocab_size, output_dim=16, input_length=max_len),
        keras.layers.LSTM(32),
        keras.layers.Dense(16, activation="relu"),
        keras.layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    model.summary()

    model.fit(X_train, y_train, epochs=epochs, batch_size=32, verbose=0,
              validation_data=(X_test, y_test))

    loss, mae = model.evaluate(X_test, y_test, verbose=0)
    print(f"[predictor] LSTM  Test MSE: {loss:.4f}  MAE: {mae:.4f}")

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        model.save(str(save_path))
        print(f"[predictor] LSTM model saved -> {save_path}")

    return model


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate
    from src.preprocessing.cleaner import clean
    from src.models.clustering import run_clustering

    root = Path(__file__).parents[2]

    raw_df = load_and_validate(root / "data" / "sample" / "sample_data.csv")
    clean_df = clean(raw_df)
    clustered_df = run_clustering(
        clean_df,
        config_path=root / "config.yaml",
        model_save_path=root / "models" / "saved" / "kmeans.pkl",
    )

    print("\n--- Random Forest Models ---")
    train_conversion_regressor(
        clustered_df,
        save_path=root / "models" / "saved" / "rf_conversion.pkl",
    )
    train_churn_classifier(
        clustered_df,
        save_path=root / "models" / "saved" / "rf_churn.pkl",
    )

    print("\n--- LSTM Model ---")
    try:
        train_lstm(
            clustered_df,
            save_path=root / "models" / "saved" / "lstm_model.h5",
            epochs=5,
        )
    except ImportError:
        print("[predictor] TensorFlow not available — skipping LSTM.")
