"""clustering.py — K-Means user segmentation.

Segments rows into three clusters based on numeric features and labels them:
    high_value  — high traffic, high conversion, high LTV
    drop_off    — mid traffic, low conversion
    low_value   — low traffic, low conversion, low LTV

Saves the fitted model to models/saved/kmeans.pkl.
"""
from __future__ import annotations

import pickle
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler

import yaml


FEATURE_COLUMNS: List[str] = [
    "traffic",
    "conversion_rate",
    "bounce_rate",
    "ltv",
    "error_rate",
]

# Mapping from cluster index (sorted by mean conversion+ltv desc) to label
CLUSTER_LABELS: List[str] = ["high_value", "drop_off", "low_value"]


def _load_config(config_path: Path) -> dict:
    """Load config.yaml and return the clustering section."""
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    return cfg.get("clustering", {"k": 3, "random_state": 42})


def fit_kmeans(
    df: pd.DataFrame,
    feature_cols: List[str] = FEATURE_COLUMNS,
    k: int = 3,
    random_state: int = 42,
) -> tuple[KMeans, np.ndarray]:
    """Fit K-Means on the given feature columns.

    Args:
        df: Cleaned DataFrame (numeric cols already normalized).
        feature_cols: Columns to use as clustering features.
        k: Number of clusters.
        random_state: Random seed for reproducibility.

    Returns:
        Tuple of (fitted KMeans model, array of raw cluster indices).
    """
    X = df[feature_cols].values
    model = KMeans(n_clusters=k, random_state=random_state, n_init=10)
    raw_labels = model.fit_predict(X)
    return model, raw_labels


def _rank_clusters(
    model: KMeans,
    feature_cols: List[str],
) -> dict[int, str]:
    """Rank raw cluster indices by descending value and return label map.

    Ranking criterion: mean(conversion_rate + ltv) across centroid features.

    Args:
        model: Fitted KMeans model.
        feature_cols: Feature column names used during fit.

    Returns:
        Dict mapping raw cluster index -> human-readable label.
    """
    centroids = pd.DataFrame(model.cluster_centers_, columns=feature_cols)
    rank_score = centroids.get("conversion_rate", 0) + centroids.get("ltv", 0)
    sorted_indices = rank_score.argsort()[::-1].tolist()
    return {raw_idx: CLUSTER_LABELS[rank] for rank, raw_idx in enumerate(sorted_indices)}


def assign_cluster_labels(
    df: pd.DataFrame,
    model: KMeans,
    raw_labels: np.ndarray,
    feature_cols: List[str] = FEATURE_COLUMNS,
) -> pd.DataFrame:
    """Map raw cluster indices to human-readable labels and append to DataFrame.

    Args:
        df: Cleaned DataFrame.
        model: Fitted KMeans model.
        raw_labels: Array of raw cluster indices from fit_kmeans.
        feature_cols: Feature columns used during clustering.

    Returns:
        New DataFrame with `cluster_label` column appended.
    """
    label_map = _rank_clusters(model, feature_cols)
    result = df.copy()
    result["cluster_label"] = [label_map[idx] for idx in raw_labels]
    return result


def save_model(model: KMeans, path: Path) -> None:
    """Persist the fitted KMeans model to disk as a pickle file.

    Args:
        model: Fitted KMeans model.
        path: Destination file path (will create parent dirs if needed).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(model, f)
    print(f"[clustering] Model saved -> {path}")


def load_model(path: Path) -> KMeans:
    """Load a previously saved KMeans model from disk.

    Args:
        path: Path to the .pkl file.

    Returns:
        Deserialized KMeans model.
    """
    with open(path, "rb") as f:
        return pickle.load(f)


def plot_elbow(
    df: pd.DataFrame,
    feature_cols: List[str] = FEATURE_COLUMNS,
    max_k: int = 8,
    save_path: Path | None = None,
) -> None:
    """Plot the K-Means elbow curve (inertia vs k).

    Args:
        df: Cleaned DataFrame with numeric features.
        feature_cols: Columns to use.
        max_k: Maximum k to test.
        save_path: If provided, save the figure there instead of showing it.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    X = df[feature_cols].values
    inertias = []
    ks = range(1, max_k + 1)
    for k in ks:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        km.fit(X)
        inertias.append(km.inertia_)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(list(ks), inertias, marker="o")
    ax.set_xlabel("k")
    ax.set_ylabel("Inertia")
    ax.set_title("K-Means Elbow Curve")
    ax.axvline(x=3, color="red", linestyle="--", label="k=3 (chosen)")
    ax.legend()
    fig.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path)
        print(f"[clustering] Elbow curve saved -> {save_path}")
    else:
        plt.show()
    plt.close(fig)


def run_clustering(
    df: pd.DataFrame,
    config_path: Path | None = None,
    model_save_path: Path | None = None,
    elbow_save_path: Path | None = None,
) -> pd.DataFrame:
    """Full clustering pipeline: fit, label, save model, plot elbow.

    Args:
        df: Cleaned DataFrame.
        config_path: Path to config.yaml (uses defaults if None).
        model_save_path: Where to save kmeans.pkl.
        elbow_save_path: Where to save elbow curve image.

    Returns:
        DataFrame with `cluster_label` column appended.
    """
    cfg = _load_config(config_path) if config_path else {"k": 3, "random_state": 42}
    k = cfg.get("k", 3)
    random_state = cfg.get("random_state", 42)

    model, raw_labels = fit_kmeans(df, k=k, random_state=random_state)
    labeled_df = assign_cluster_labels(df, model, raw_labels)

    print("[clustering] Cluster distribution:")
    print(labeled_df["cluster_label"].value_counts().to_string())

    if model_save_path:
        save_model(model, model_save_path)

    if elbow_save_path:
        plot_elbow(df, save_path=elbow_save_path)

    return labeled_df


if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate
    from src.preprocessing.cleaner import clean

    root = Path(__file__).parents[2]
    raw_df = load_and_validate(root / "data" / "sample" / "sample_data.csv")
    clean_df = clean(raw_df)

    labeled_df = run_clustering(
        clean_df,
        config_path=root / "config.yaml",
        model_save_path=root / "models" / "saved" / "kmeans.pkl",
        elbow_save_path=root / "models" / "saved" / "elbow_curve.png",
    )

    print("\nSample output:")
    print(labeled_df[["domain", "traffic", "conversion_rate", "ltv", "cluster_label"]].head(10))
