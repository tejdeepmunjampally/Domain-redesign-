"""ranker.py — Priority ranking and what-if redesign simulation.

Takes the scored domain DataFrame and:
- Assigns HIGH / MEDIUM / LOW priority based on config thresholds
- Implements simulate_redesign() to predict score and revenue delta
  after hypothetical changes to conversion_rate or error_rate
"""
from __future__ import annotations

from pathlib import Path
from typing import NamedTuple

import pandas as pd
import yaml


class RedesignResult(NamedTuple):
    """Return value of simulate_redesign."""

    domain: str
    original_score: float
    new_score: float
    score_delta: float
    revenue_delta: float


def load_thresholds(config_path: Path) -> dict[str, float]:
    """Read priority thresholds from config.yaml.

    Args:
        config_path: Path to config.yaml.

    Returns:
        Dict with keys 'high' and 'medium'.
    """
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    return cfg["priority_thresholds"]


def assign_priority(
    scored_df: pd.DataFrame,
    thresholds: dict[str, float],
) -> pd.DataFrame:
    """Add a `priority` column based on impact_score thresholds.

    Mapping:
        score >= high_threshold  -> HIGH
        score >= medium_threshold -> MEDIUM
        otherwise                -> LOW

    Args:
        scored_df: Per-domain DataFrame with `impact_score` column.
        thresholds: Dict with 'high' and 'medium' float keys.

    Returns:
        New DataFrame with `priority` column appended.
    """
    high = thresholds["high"]
    medium = thresholds["medium"]

    def _label(score: float) -> str:
        if score >= high:
            return "HIGH"
        if score >= medium:
            return "MEDIUM"
        return "LOW"

    result = scored_df.copy()
    result["priority"] = result["impact_score"].apply(_label)
    return result


def rank_domains(
    scored_df: pd.DataFrame,
    config_path: Path,
) -> pd.DataFrame:
    """Assign priority labels and return a ranked domain table.

    Args:
        scored_df: Output of scorer.score_domains().
        config_path: Path to config.yaml.

    Returns:
        DataFrame sorted by impact_score descending with priority column.
    """
    thresholds = load_thresholds(config_path)
    ranked = assign_priority(scored_df, thresholds)
    return ranked.sort_values("impact_score", ascending=False).reset_index(drop=True)


def simulate_redesign(
    ranked_df: pd.DataFrame,
    domain: str,
    weights: dict[str, float],
    delta_conversion: float = 0.0,
    delta_error: float = 0.0,
    avg_ltv: float = 100.0,
) -> RedesignResult:
    """Predict new impact score and revenue delta after a hypothetical redesign.

    Applies additive deltas to conversion_rate and error_rate for a single
    domain, recomputes its impact score using the same weight formula, and
    estimates revenue delta from the change in conversion rate scaled by LTV.

    Args:
        ranked_df: Output of rank_domains() with one row per domain.
        domain: The target domain to simulate.
        weights: Impact score weight dict from config.yaml.
        delta_conversion: Change in conversion_rate (e.g. +0.05 = +5 pp).
        delta_error: Change in error_rate (e.g. -0.02 = -2 pp improvement).
        avg_ltv: Average LTV per converted session used for revenue estimate.

    Returns:
        RedesignResult namedtuple with original/new scores and revenue delta.

    Raises:
        ValueError: If the domain is not found in ranked_df.
    """
    row = ranked_df[ranked_df["domain"] == domain]
    if row.empty:
        raise ValueError(f"Domain '{domain}' not found in ranked DataFrame.")

    row = row.iloc[0]
    original_score = float(row["impact_score"])

    new_conversion = float(
        min(1.0, max(0.0, row["conversion_rate"] + delta_conversion))
    )
    new_error = float(min(1.0, max(0.0, row["error_rate"] + delta_error)))

    new_score = (
        weights.get("traffic", 0.0) * float(row["traffic"])
        + weights.get("conversion_rate", 0.0) * new_conversion
        + weights.get("ltv", 0.0) * float(row["ltv"])
        - weights.get("churn_risk", 0.0) * float(row.get("churn_risk", 0.0))
        - weights.get("error_rate", 0.0) * new_error
    )
    new_score = float(min(1.0, max(0.0, new_score)))

    # Revenue delta: delta_conversion * traffic_volume * avg_ltv
    # traffic here is normalized [0,1]; treat it as a relative session volume
    traffic_vol = float(row["traffic"])
    revenue_delta = delta_conversion * traffic_vol * avg_ltv

    return RedesignResult(
        domain=domain,
        original_score=round(original_score, 4),
        new_score=round(new_score, 4),
        score_delta=round(new_score - original_score, 4),
        revenue_delta=round(revenue_delta, 2),
    )


if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate
    from src.preprocessing.cleaner import clean
    from src.models.clustering import run_clustering
    from src.models.predictor import _derive_churn_risk
    from src.models.scorer import score_domains, load_weights

    root = Path(__file__).parents[2]

    raw_df = load_and_validate(root / "data" / "sample" / "sample_data.csv")
    clean_df = clean(raw_df)
    clustered_df = run_clustering(clean_df, config_path=root / "config.yaml")
    clustered_df = _derive_churn_risk(clustered_df)

    scored_df = score_domains(clustered_df, config_path=root / "config.yaml")
    ranked_df = rank_domains(scored_df, config_path=root / "config.yaml")
    weights = load_weights(root / "config.yaml")

    print("Ranked Domain Table:")
    print(
        ranked_df[["domain", "impact_score", "priority"]].to_string(index=False)
    )

    print("\nWhat-If Simulation:")
    for domain in ranked_df["domain"].head(3):
        result = simulate_redesign(
            ranked_df,
            domain=domain,
            weights=weights,
            delta_conversion=0.05,
            delta_error=-0.01,
        )
        print(
            f"  {result.domain:<28} "
            f"score {result.original_score:.4f} -> {result.new_score:.4f} "
            f"(+{result.score_delta:.4f})  "
            f"rev delta: ${result.revenue_delta:.2f}"
        )
