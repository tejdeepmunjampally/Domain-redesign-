"""journey.py — Reconstruct per-session user journey paths and tag outcomes.

Responsibilities:
- Group rows by session_id
- Build the full click path sequence per session
- Tag each session as: converted, dropped, or bounced
- Identify drop-off points and conversion paths
"""
from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd


# Keywords that indicate a conversion step in the click path
CONVERSION_KEYWORDS: List[str] = ["checkout", "signup", "apply", "dashboard"]

# Keywords that indicate an explicit drop-off
DROP_KEYWORDS: List[str] = ["drop"]


def tag_session_outcome(path: List[str]) -> str:
    """Determine the outcome of a session from its click path.

    Rules (checked in order):
    1. ``converted``  — path contains a conversion keyword
    2. ``bounced``    — path has only one step (landed and left)
    3. ``dropped``    — path contains a drop keyword
    4. ``dropped``    — default fallback

    Args:
        path: Ordered list of page/step tokens for one session.

    Returns:
        One of: ``"converted"``, ``"bounced"``, ``"dropped"``.
    """
    if any(step in CONVERSION_KEYWORDS for step in path):
        return "converted"
    if len(path) == 1:
        return "bounced"
    if any(step in DROP_KEYWORDS for step in path):
        return "dropped"
    return "dropped"


def build_journey_table(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate per-session journey information from the cleaned DataFrame.

    Each row in the output represents one session with:
    - ``session_id``    — unique session identifier
    - ``domain``        — domain visited (first domain in session)
    - ``path``          — full list of click-path steps
    - ``path_length``   — number of steps
    - ``outcome``       — converted / dropped / bounced
    - ``drop_off_point``— last step before exit (for non-conversions)

    Args:
        df: Cleaned DataFrame from cleaner.py. Expects ``click_path`` to be
            either a list of tokens or a ``>``-delimited string.

    Returns:
        New DataFrame with one row per session.
    """
    result = df.copy()

    # Normalise click_path to list if it is still a string (e.g. loaded from CSV)
    if result["click_path"].dtype == object and isinstance(
        result["click_path"].iloc[0], str
    ):
        result["click_path"] = result["click_path"].str.split(">")

    rows = []
    for session_id, group in result.groupby("session_id"):
        # Flatten all click paths across rows for the session
        all_steps: List[str] = []
        for path in group["click_path"]:
            all_steps.extend(path if isinstance(path, list) else path.split(">"))

        # Deduplicate consecutive duplicates while preserving order
        deduped: List[str] = []
        for step in all_steps:
            if not deduped or step != deduped[-1]:
                deduped.append(step)

        domain = group["domain"].iloc[0]
        outcome = tag_session_outcome(deduped)
        drop_off = deduped[-1] if outcome != "converted" else None

        rows.append(
            {
                "session_id": session_id,
                "domain": domain,
                "path": deduped,
                "path_length": len(deduped),
                "outcome": outcome,
                "drop_off_point": drop_off,
            }
        )

    return pd.DataFrame(rows)


def summarise_by_domain(journey_df: pd.DataFrame) -> pd.DataFrame:
    """Summarise journey outcomes aggregated per domain.

    Args:
        journey_df: Output of :func:`build_journey_table`.

    Returns:
        DataFrame with columns: domain, total_sessions, converted,
        dropped, bounced, conversion_rate, drop_rate, bounce_rate.
    """
    grouped = journey_df.groupby("domain")
    summary = grouped["outcome"].value_counts().unstack(fill_value=0)

    for col in ("converted", "dropped", "bounced"):
        if col not in summary.columns:
            summary[col] = 0

    summary["total_sessions"] = summary[["converted", "dropped", "bounced"]].sum(axis=1)
    summary["conversion_rate"] = summary["converted"] / summary["total_sessions"]
    summary["drop_rate"] = summary["dropped"] / summary["total_sessions"]
    summary["bounce_rate"] = summary["bounced"] / summary["total_sessions"]

    return summary.reset_index()[
        [
            "domain",
            "total_sessions",
            "converted",
            "dropped",
            "bounced",
            "conversion_rate",
            "drop_rate",
            "bounce_rate",
        ]
    ]


if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate
    from src.preprocessing.cleaner import clean

    root = Path(__file__).parents[2]
    raw_path = root / "data" / "sample" / "sample_data.csv"

    raw_df = load_and_validate(raw_path)
    clean_df = clean(raw_df)
    journey_df = build_journey_table(clean_df)
    summary_df = summarise_by_domain(journey_df)

    print("Journey table (first 5 rows):")
    print(journey_df.head())
    print("\nOutcome counts:")
    print(journey_df["outcome"].value_counts())
    print("\nDomain summary:")
    print(summary_df.to_string(index=False))
