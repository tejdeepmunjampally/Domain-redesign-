"""app.py — Domain Forge AI Streamlit Dashboard."""
from __future__ import annotations

from io import StringIO
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import yaml

ROOT        = Path(__file__).parents[2]
CONFIG_PATH = ROOT / "config.yaml"
SAMPLE_PATH = ROOT / "data" / "sample" / "sample_data.csv"

# ── Page config (must be first) ──────────────────────────────────────────────
st.set_page_config(
    page_title="Domain Forge AI",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Theme CSS — no backdrop-filter, no complex HTML injection ─────────────────
st.markdown("""
<style>
/* Background */
[data-testid="stAppViewContainer"] > .main {
    background: linear-gradient(160deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
    min-height: 100vh;
}
[data-testid="stHeader"] { background: transparent; }
[data-testid="stSidebar"] {
    background: rgba(20, 18, 50, 0.95);
    border-right: 1px solid rgba(255,255,255,0.08);
}

/* Hide default chrome */
#MainMenu, footer { visibility: hidden; }

/* Headings */
h1, h2, h3, h4 { color: #e2e0ff !important; }

/* Metric widget */
[data-testid="metric-container"] {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 12px;
    padding: 0.8rem 1rem;
}
[data-testid="metric-container"] label { color: #9999cc !important; }
[data-testid="metric-container"] [data-testid="stMetricValue"] {
    color: #a78bfa !important;
    font-size: 1.8rem !important;
    font-weight: 700 !important;
}

/* Dataframe */
[data-testid="stDataFrame"] {
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    overflow: hidden;
}

/* Download button */
[data-testid="stDownloadButton"] button {
    background: linear-gradient(135deg, #7c3aed, #4f46e5) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.55rem 1.6rem !important;
    font-weight: 600 !important;
}

/* Selectbox / slider labels */
label { color: #c4b5fd !important; }

/* Expander */
[data-testid="stExpander"] summary {
    color: #c4b5fd !important;
    font-weight: 600;
}

/* Plotly charts — transparent background */
.js-plotly-plot .plotly, .js-plotly-plot .plotly .svg-container {
    background: transparent !important;
}

/* Sidebar text */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label { color: #b0b0d0 !important; }
</style>
""", unsafe_allow_html=True)

# ── Shared Plotly dark layout ─────────────────────────────────────────────────
_PLT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(255,255,255,0.03)",
    font=dict(color="#d0d0e8", family="Segoe UI", size=12),
    xaxis=dict(gridcolor="rgba(255,255,255,0.07)", zerolinecolor="rgba(255,255,255,0.1)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.07)", zerolinecolor="rgba(255,255,255,0.1)"),
    legend=dict(bgcolor="rgba(0,0,0,0.2)", bordercolor="rgba(255,255,255,0.1)", borderwidth=1),
    margin=dict(l=10, r=20, t=50, b=10),
)

PRIORITY_COLORS = {"HIGH": "#ef4444", "MEDIUM": "#f59e0b", "LOW": "#22c55e"}
CLUSTER_COLORS  = {"high_value": "#34d399", "drop_off": "#fb923c", "low_value": "#f87171"}
CLUSTER_FILL    = {
    "high_value": "rgba(52,211,153,0.15)",
    "drop_off":   "rgba(251,146,60,0.15)",
    "low_value":  "rgba(248,113,113,0.15)",
}

# ── Cached helpers ────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def _load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


@st.cache_data(show_spinner=False)
def run_pipeline(csv_bytes: bytes) -> tuple[pd.DataFrame, pd.DataFrame]:
    import sys
    sys.path.insert(0, str(ROOT))
    from src.ingestion.data_loader import validate_columns, validate_numeric_ranges
    from src.preprocessing.cleaner import clean
    from src.models.clustering import run_clustering
    from src.models.predictor import _derive_churn_risk
    from src.models.scorer import score_domains
    from src.recommendation.ranker import rank_domains

    raw_df = pd.read_csv(StringIO(csv_bytes.decode("utf-8")))
    validate_columns(raw_df)
    validate_numeric_ranges(raw_df)
    clean_df     = clean(raw_df)
    clustered_df = run_clustering(clean_df, config_path=CONFIG_PATH)
    clustered_df = _derive_churn_risk(clustered_df)
    scored_df    = score_domains(clustered_df, config_path=CONFIG_PATH)
    ranked_df    = rank_domains(scored_df, config_path=CONFIG_PATH)
    return clustered_df, ranked_df

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔥 Domain Forge AI")
    st.divider()
    use_sample    = st.radio("Data source", ["Sample dataset", "Upload CSV"], index=0)
    uploaded_file = None
    if use_sample == "Upload CSV":
        uploaded_file = st.file_uploader("Upload analytics CSV", type=["csv"])
    st.divider()
    st.caption("K-Means · Random Forest · Impact Scoring")
    st.caption("Team Paradise · Vignan Institute of Technology and Science")

# ── Hero header ───────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center; padding:2rem 0 1rem;">
  <p style="font-size:3rem; margin:0;">🔥</p>
  <h1 style="
    margin:0.2rem 0 0;
    font-size:2.6rem;
    font-weight:800;
    background:linear-gradient(90deg,#a78bfa,#60a5fa,#34d399);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
  ">Domain Forge AI</h1>
  <p style="color:#7777aa; font-size:0.95rem; letter-spacing:0.08em; margin-top:0.4rem;">
    ML-POWERED DOMAIN PRIORITIZATION FOR REDESIGN DECISIONS
  </p>
</div>
""", unsafe_allow_html=True)

# ── Load data ─────────────────────────────────────────────────────────────────
if use_sample == "Sample dataset":
    csv_bytes = SAMPLE_PATH.read_bytes()
else:
    if uploaded_file is None:
        st.info("Upload a CSV file from the sidebar to begin.")
        st.stop()
    csv_bytes = uploaded_file.read()

with st.spinner("⚙️ Running ML pipeline…"):
    try:
        clustered_df, ranked_df = run_pipeline(csv_bytes)
    except Exception as exc:
        st.error(f"Pipeline error: {exc}")
        st.stop()

raw_preview = pd.read_csv(StringIO(csv_bytes.decode("utf-8")))
cfg         = _load_config()
weights     = cfg["impact_score"]["weights"]
high_n      = int((ranked_df["priority"] == "HIGH").sum())
med_n       = int((ranked_df["priority"] == "MEDIUM").sum())
low_n       = int((ranked_df["priority"] == "LOW").sum())

# ── KPI strip ─────────────────────────────────────────────────────────────────
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total Sessions",   len(raw_preview))
k2.metric("Domains Analysed", raw_preview["domain"].nunique())
k3.metric("HIGH Priority",    high_n)
k4.metric("MEDIUM Priority",  med_n)
k5.metric("Top Score",        f"{ranked_df['impact_score'].max():.3f}")

st.divider()

# ── Section 1 — Raw data preview ──────────────────────────────────────────────
with st.expander("📋  Raw Data Preview", expanded=False):
    st.dataframe(raw_preview, width="stretch", height=220)

st.divider()

# ── Section 2 — Priority Rankings ────────────────────────────────────────────
st.markdown("### 📊  Domain Priority Rankings")

display_cols = ["domain", "impact_score", "priority", "traffic",
                "conversion_rate", "ltv", "churn_risk", "error_rate"]
present_cols = [c for c in display_cols if c in ranked_df.columns]
table_df     = ranked_df[present_cols].copy()

for col in ["impact_score", "traffic", "conversion_rate", "ltv", "churn_risk", "error_rate"]:
    if col in table_df.columns:
        table_df[col] = table_df[col].round(4)

def _highlight(row: pd.Series) -> list[str]:
    colors = {"HIGH": "background-color:#4a1515; color:#fca5a5",
              "MEDIUM": "background-color:#3d2c0a; color:#fcd34d",
              "LOW": "background-color:#0d2e1a; color:#86efac"}
    style = colors.get(row.get("priority", ""), "")
    return [style] * len(row)

st.dataframe(
    table_df.style.apply(_highlight, axis=1),
    width="stretch", height=360,
)

c1, c2, c3 = st.columns(3)
c1.metric("🔴  HIGH priority",   high_n)
c2.metric("🟡  MEDIUM priority", med_n)
c3.metric("🟢  LOW priority",    low_n)

st.divider()

# ── Section 3 & 4 — Charts side by side ──────────────────────────────────────
st.markdown("### 📈  Visual Analytics")

col_bar, col_scatter = st.columns(2)

with col_bar:
    bar_df          = ranked_df[["domain", "impact_score", "priority"]].copy()
    bar_df["label"] = bar_df["domain"].str.replace(".example.com", "", regex=False)

    fig_bar = px.bar(
        bar_df.sort_values("impact_score"),
        x="impact_score", y="label",
        color="priority",
        color_discrete_map=PRIORITY_COLORS,
        orientation="h",
        text="impact_score",
        labels={"impact_score": "Impact Score", "label": "Domain"},
        title="Impact Score by Domain",
    )
    fig_bar.update_traces(
        texttemplate="%{text:.3f}",
        textposition="outside",
        textfont=dict(color="#d0d0e8", size=11),
        marker_line_width=0,
    )
    fig_bar.update_layout(
        **_PLT, height=400, xaxis_range=[0, 1.15],
        title_font_size=14, title_font_color="#c4b5fd",
    )
    fig_bar.add_vline(x=0.7, line_dash="dot", line_color="#ef4444", line_width=1.5,
                      annotation_text="HIGH", annotation_font_color="#ef4444",
                      annotation_position="top right")
    fig_bar.add_vline(x=0.4, line_dash="dot", line_color="#f59e0b", line_width=1.5,
                      annotation_text="MED", annotation_font_color="#f59e0b",
                      annotation_position="bottom right")
    st.plotly_chart(fig_bar, width="stretch")

with col_scatter:
    fig_scatter = px.scatter(
        clustered_df,
        x="traffic", y="conversion_rate",
        color="cluster_label",
        color_discrete_map=CLUSTER_COLORS,
        hover_data=["domain", "ltv", "bounce_rate", "error_rate"],
        labels={
            "traffic": "Traffic (normalised)",
            "conversion_rate": "Conversion Rate (normalised)",
            "cluster_label": "Cluster",
        },
        title="Traffic vs Conversion Rate by Cluster",
        opacity=0.80,
    )
    fig_scatter.update_traces(
        marker=dict(size=9, line=dict(width=0.5, color="rgba(0,0,0,0.4)"))
    )
    fig_scatter.update_layout(
        **_PLT, height=400,
        title_font_size=14, title_font_color="#c4b5fd",
    )
    st.plotly_chart(fig_scatter, width="stretch")

# ── Donut + Radar ─────────────────────────────────────────────────────────────
col_donut, col_radar = st.columns(2)
cluster_counts = clustered_df["cluster_label"].value_counts().reset_index()
cluster_counts.columns = ["Cluster", "Sessions"]

with col_donut:
    fig_donut = go.Figure(go.Pie(
        labels=cluster_counts["Cluster"],
        values=cluster_counts["Sessions"],
        hole=0.55,
        marker=dict(
            colors=[CLUSTER_COLORS.get(c, "#888") for c in cluster_counts["Cluster"]],
            line=dict(color="rgba(0,0,0,0.4)", width=2),
        ),
        textinfo="label+percent",
        textfont=dict(color="#e2e2f5", size=12),
        insidetextorientation="radial",
    ))
    fig_donut.update_layout(
        **_PLT, height=300,
        title="User Cluster Distribution",
        title_font_size=14, title_font_color="#c4b5fd",
        showlegend=True,
    )
    st.plotly_chart(fig_donut, width="stretch")

with col_radar:
    cluster_summary = (
        clustered_df.groupby("cluster_label")[
            ["traffic", "conversion_rate", "ltv", "churn_risk", "error_rate"]
        ].mean().round(3).reset_index()
    )
    cats = ["traffic", "conversion_rate", "ltv", "churn_risk", "error_rate"]
    cat_labels = ["Traffic", "Conv Rate", "LTV", "Churn Risk", "Error Rate"]

    radar_traces = []
    for _, row in cluster_summary.iterrows():
        vals = [row[c] for c in cats]
        radar_traces.append(go.Scatterpolar(
            r=vals + [vals[0]],
            theta=cat_labels + [cat_labels[0]],
            fill="toself",
            name=row["cluster_label"],
            line=dict(color=CLUSTER_COLORS.get(row["cluster_label"], "#888"), width=2),
            fillcolor=CLUSTER_FILL.get(row["cluster_label"], "rgba(136,136,136,0.15)"),
        ))

    fig_radar = go.Figure(radar_traces)
    fig_radar.update_layout(
        **_PLT, height=300,
        title="Cluster Feature Profiles",
        title_font_size=14, title_font_color="#c4b5fd",
        polar=dict(
            bgcolor="rgba(255,255,255,0.03)",
            radialaxis=dict(
                visible=True, range=[0, 1],
                color="#888899", gridcolor="rgba(255,255,255,0.1)",
                tickfont=dict(size=9, color="#888899"),
            ),
            angularaxis=dict(
                color="#aaaacc",
                gridcolor="rgba(255,255,255,0.1)",
                tickfont=dict(size=11, color="#c4b5fd"),
            ),
        ),
    )
    st.plotly_chart(fig_radar, width="stretch")

with st.expander("📋  Cluster Summary Statistics", expanded=False):
    st.dataframe(
        cluster_summary.rename(columns={
            "cluster_label": "Cluster", "traffic": "Traffic",
            "conversion_rate": "Conv Rate", "ltv": "LTV",
            "churn_risk": "Churn Risk", "error_rate": "Error Rate",
        }),
        width="stretch",
    )

st.divider()

# ── Section 5 — What-If Simulator ────────────────────────────────────────────
from src.recommendation.ranker import simulate_redesign  # noqa: E402

st.markdown("### 🧪  What-If Redesign Simulator")
st.caption("Adjust sliders to simulate the impact of a redesign on Impact Score and revenue.")

sim_l, sim_r = st.columns([1, 1])

with sim_l:
    selected_domain = st.selectbox("🌐  Select domain", ranked_df["domain"].tolist())
    delta_conv = st.slider("📈  Conversion rate change (pp)", -0.20, 0.40, 0.05, 0.01,
                           format="%.2f", help="+0.05 = +5 percentage points")
    delta_err  = st.slider("🐛  Error rate change (pp)",      -0.20, 0.10, -0.02, 0.01,
                           format="%.2f", help="-0.02 = 2pp fewer errors")
    avg_ltv    = st.number_input("💰  Avg LTV per session ($)", 1.0, 10000.0, 150.0, 10.0)

sim = simulate_redesign(
    ranked_df, domain=selected_domain, weights=weights,
    delta_conversion=delta_conv, delta_error=delta_err, avg_ltv=avg_ltv,
)

score_color = "#34d399" if sim.score_delta >= 0 else "#f87171"
rev_color   = "#34d399" if sim.revenue_delta >= 0 else "#f87171"
arrow       = "▲" if sim.score_delta >= 0 else "▼"
rev_arrow   = "▲" if sim.revenue_delta >= 0 else "▼"

with sim_r:
    # Results in native Streamlit metrics — no HTML injection
    r1, r2, r3 = st.columns(3)
    r1.metric("Original Score", f"{sim.original_score:.4f}")
    r2.metric("New Score",      f"{sim.new_score:.4f}",
              delta=f"{sim.score_delta:+.4f}")
    r3.metric("Revenue Delta",  f"${sim.revenue_delta:+.2f}")

    # Gauge
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=sim.new_score,
        delta={
            "reference": sim.original_score,
            "valueformat": ".4f",
            "increasing": {"color": "#34d399"},
            "decreasing": {"color": "#f87171"},
        },
        number={"valueformat": ".4f", "font": {"color": "#e2e2f5", "size": 26}},
        gauge={
            "axis": {"range": [0, 1],
                     "tickcolor": "#666688",
                     "tickfont": {"color": "#9999bb", "size": 10}},
            "bar": {"color": score_color, "thickness": 0.22},
            "bgcolor": "rgba(0,0,0,0)",
            "borderwidth": 0,
            "steps": [
                {"range": [0.0, 0.4], "color": "rgba(34,197,94,0.10)"},
                {"range": [0.4, 0.7], "color": "rgba(245,158,11,0.10)"},
                {"range": [0.7, 1.0], "color": "rgba(239,68,68,0.10)"},
            ],
            "threshold": {
                "line": {"color": "#a78bfa", "width": 3},
                "thickness": 0.75,
                "value": sim.original_score,
            },
        },
        title={"text": f"Impact Score — {selected_domain}",
               "font": {"color": "#9999cc", "size": 12}},
    ))
    fig_gauge.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#d0d0e8"),
        height=240,
        margin=dict(l=20, r=20, t=60, b=10),
    )
    st.plotly_chart(fig_gauge, width="stretch")

st.divider()

# ── Footer — Download ─────────────────────────────────────────────────────────
st.markdown("### ⬇️  Export Recommendations")

download_df = ranked_df[present_cols].copy()
for col in ["impact_score", "traffic", "conversion_rate", "ltv", "churn_risk", "error_rate"]:
    if col in download_df.columns:
        download_df[col] = download_df[col].round(4)

csv_out = download_df.to_csv(index=False).encode("utf-8")
st.download_button(
    label="⬇️  Download ranked domains as CSV",
    data=csv_out,
    file_name="domain_forge_recommendations.csv",
    mime="text/csv",
)

st.divider()
st.caption("🔥 Domain Forge AI · Team Paradise · Vignan Institute of Technology and Science")
