"""data_loader.py — Load and validate domain analytics CSVs.

Produces a unified DataFrame with columns:
    domain, session_id, traffic, conversion_rate, bounce_rate, ltv, error_rate, click_path
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd


REQUIRED_COLUMNS: list[str] = [
    "domain",
    "session_id",
    "traffic",
    "conversion_rate",
    "bounce_rate",
    "ltv",
    "error_rate",
    "click_path",
]

NUMERIC_COLUMNS: list[str] = [
    "traffic",
    "conversion_rate",
    "bounce_rate",
    "ltv",
    "error_rate",
]


def load_csv(path: Path | str) -> pd.DataFrame:
    """Load a CSV file and return a DataFrame.

    Args:
        path: Absolute or relative path to the CSV file.

    Returns:
        Raw DataFrame loaded from the CSV.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If required columns are missing.
    """
    csv_path = Path(path)
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    df = pd.read_csv(csv_path)
    return df


def validate_columns(df: pd.DataFrame, required: list[str] = REQUIRED_COLUMNS) -> None:
    """Validate that all required columns exist in the DataFrame.

    Args:
        df: The DataFrame to validate.
        required: List of required column names.

    Raises:
        ValueError: If one or more required columns are missing.
    """
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")


def validate_numeric_ranges(df: pd.DataFrame) -> None:
    """Validate that rate columns (traffic, conversion_rate, bounce_rate, error_rate)
    are within [0, 1] and ltv is non-negative.

    Args:
        df: The DataFrame to validate.

    Raises:
        ValueError: If any column has out-of-range values.
    """
    rate_cols = ["traffic", "conversion_rate", "bounce_rate", "error_rate"]
    for col in rate_cols:
        if col in df.columns:
            if df[col].lt(0).any() or df[col].gt(1).any():
                raise ValueError(f"Column '{col}' contains values outside [0, 1].")
    if "ltv" in df.columns and df["ltv"].lt(0).any():
        raise ValueError("Column 'ltv' contains negative values.")


def load_and_validate(path: Path | str) -> pd.DataFrame:
    """Load a CSV, validate schema and value ranges, and return a clean DataFrame.

    Args:
        path: Path to the CSV file.

    Returns:
        Validated DataFrame ready for downstream processing.
    """
    df = load_csv(path)
    validate_columns(df)
    validate_numeric_ranges(df)
    return df


if __name__ == "__main__":
    # Default: load the bundled sample data
    sample_path = Path(__file__).parents[2] / "data" / "sample" / "sample_data.csv"
    df = load_and_validate(sample_path)
    print(f"Loaded shape: {df.shape}")
    print(df.head())
    print("\nColumn dtypes:")
    print(df.dtypes)
    print("\nNull counts:")
    print(df.isnull().sum())
