"""cleaner.py — Clean and normalize the raw domain analytics DataFrame.

Responsibilities:
- Drop rows with null values
- Min-max normalize all numeric columns to [0, 1]
- Encode click_path as a list of step tokens
"""
from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
from sklearn.preprocessing import MinMaxScaler


NUMERIC_COLUMNS: List[str] = [
    "traffic",
    "conversion_rate",
    "bounce_rate",
    "ltv",
    "error_rate",
]


def drop_nulls(df: pd.DataFrame) -> pd.DataFrame:
    """Drop all rows that contain at least one null value.

    Args:
        df: Input DataFrame.

    Returns:
        New DataFrame with null rows removed.
    """
    cleaned = df.dropna()
    dropped = len(df) - len(cleaned)
    if dropped:
        print(f"[cleaner] Dropped {dropped} rows with nulls.")
    return cleaned.reset_index(drop=True)


def normalize_numeric(df: pd.DataFrame, columns: List[str] = NUMERIC_COLUMNS) -> pd.DataFrame:
    """Apply Min-Max normalization to the specified numeric columns.

    Columns that are already in [0, 1] (e.g. rate columns) are re-scaled
    using the data's observed min/max so the scaler fits the actual range.

    Args:
        df: Input DataFrame. Must contain all columns listed in `columns`.
        columns: Columns to normalize.

    Returns:
        New DataFrame with normalized columns; all other columns unchanged.
    """
    result = df.copy()
    present = [c for c in columns if c in result.columns]
    scaler = MinMaxScaler()
    result[present] = scaler.fit_transform(result[present])
    return result


def encode_click_path(df: pd.DataFrame, column: str = "click_path") -> pd.DataFrame:
    """Split the click_path string into a list of step tokens.

    E.g. "home>shop>checkout" becomes ["home", "shop", "checkout"].

    Args:
        df: Input DataFrame containing a `click_path` string column.
        column: Name of the column to encode.

    Returns:
        New DataFrame with `click_path` replaced by a list-of-tokens column,
        and a new `click_path_str` column preserving the original string.
    """
    result = df.copy()
    result["click_path_str"] = result[column]
    result[column] = result[column].str.split(">")
    return result


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Full cleaning pipeline: drop nulls, normalize numerics, encode paths.

    Args:
        df: Raw input DataFrame from data_loader.

    Returns:
        Cleaned and normalized DataFrame ready for analysis.
    """
    df = drop_nulls(df)
    df = normalize_numeric(df)
    df = encode_click_path(df)
    return df


if __name__ == "__main__":
    from src.ingestion.data_loader import load_and_validate

    root = Path(__file__).parents[2]
    raw_path = root / "data" / "sample" / "sample_data.csv"
    out_path = root / "data" / "processed" / "clean_data.csv"

    raw_df = load_and_validate(raw_path)
    clean_df = clean(raw_df)

    # Persist: store click_path as the joined string for CSV compatibility
    csv_df = clean_df.copy()
    csv_df["click_path"] = csv_df["click_path"].apply(">".join)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    csv_df.to_csv(out_path, index=False)

    print(f"Cleaned shape: {clean_df.shape}")
    print(clean_df.head())
    print(f"\nSaved -> {out_path}")
