# plan.md — Domain Forge AI Execution Plan

## Project Goal

Build and demo a working MVP of Domain Forge AI:
an ML system that scores and ranks website domains for redesign priority.

---

## Phase Overview

| Phase | Name | Duration | Output |
|---|---|---|---|
| 1 | Setup & Data | Day 1 | Repo + sample dataset ready |
| 2 | Preprocessing & Analysis | Day 2 | Clean data + journey paths |
| 3 | ML Models | Day 3–4 | Clustering + prediction models |
| 4 | Scoring & Ranking | Day 5 | Impact scores + priority list |
| 5 | Dashboard | Day 6 | Streamlit app running |
| 6 | Polish & Deploy | Day 7 | CI/CD + final demo ready |

---

## Phase 1 — Setup & Data (Day 1)

### Goals
- Initialize repo and folder structure
- Generate or collect sample data
- Define config

### Tasks

- [ ] Create project folder structure (as in `CLAUDE.md`)
- [ ] Initialize Git + GitLab repo
- [ ] Write `requirements.txt`
  - pandas, numpy, scikit-learn, tensorflow, streamlit, plotly, pyyaml
- [ ] Create `config.yaml` with default weights and thresholds
- [ ] Generate `sample_data.csv` with columns:
  - `domain`, `session_id`, `traffic`, `conversion_rate`, `bounce_rate`, `ltv`, `error_rate`, `click_path`
- [ ] Write `data_loader.py` to read and validate CSVs

### Deliverable
Working data ingestion: `python src/ingestion/data_loader.py` prints loaded DataFrame shape.

---

## Phase 2 — Preprocessing & Journey Analysis (Day 2)

### Goals
- Clean and normalize data
- Extract user journey paths

### Tasks

- [ ] `cleaner.py`
  - Drop nulls
  - Min-max normalize numeric columns
  - Encode `click_path` as list of domain tokens
- [ ] `journey.py`
  - Group by `session_id`, sort by timestamp
  - Build per-session path: `[home → shop → checkout → drop]`
  - Tag each session as: `converted`, `dropped`, `bounced`
- [ ] Write unit test: `test_cleaner.py`

### Deliverable
`processed/clean_data.csv` — normalized, journey-tagged dataset.

---

## Phase 3 — ML Models (Day 3–4)

### Goals
- Segment users via clustering
- Predict conversion probability and churn risk per domain

### Tasks

**Day 3 — Clustering**
- [ ] `clustering.py`
  - Input: numeric feature columns
  - Apply K-Means (k=3, random_state=42)
  - Label clusters: `high_value`, `drop_off`, `low_value`
  - Save cluster model: `models/saved/kmeans.pkl`
  - Plot elbow curve to validate k

**Day 4 — Predictive Models**
- [ ] `predictor.py` — Random Forest
  - Features: traffic, bounce_rate, error_rate, cluster_label
  - Target 1: `conversion_probability` (regression)
  - Target 2: `churn_risk` (classification)
  - Save model: `models/saved/rf_model.pkl`
- [ ] `predictor.py` — LSTM (optional, add if time permits)
  - Input: encoded click_path sequences (padded)
  - Output: predicted future conversion score
  - Save model: `models/saved/lstm_model.h5`
- [ ] Evaluate models: print accuracy / RMSE to console

### Deliverable
Models saved. `python src/models/predictor.py` runs training and prints eval metrics.

---

## Phase 4 — Scoring & Ranking (Day 5)

### Goals
- Compute Domain Impact Score for each domain
- Rank into HIGH / MEDIUM / LOW priority
- Implement what-if simulation

### Tasks

- [ ] `scorer.py`
  - Aggregate per-domain: mean traffic, conversion, ltv, churn, error
  - Apply weighted formula from `config.yaml`
  - Output: DataFrame with `domain` + `impact_score`
- [ ] `ranker.py`
  - Apply priority thresholds (high ≥ 0.7, medium ≥ 0.4)
  - Add `priority` column: `HIGH / MEDIUM / LOW`
  - Implement `simulate_redesign(domain, delta_conversion, delta_error)`
    - Returns predicted new score and revenue delta
- [ ] Write `test_scorer.py`

### Deliverable
`python src/recommendation/ranker.py` prints ranked domain table with priorities.

---

## Phase 5 — Streamlit Dashboard (Day 6)

### Goals
- Build interactive frontend for results

### Tasks

- [ ] `app.py` — layout:
  - **Header**: Domain Forge AI logo + title
  - **Section 1**: Upload CSV or use sample data
  - **Section 2**: Domain Priority Table (color-coded HIGH/MEDIUM/LOW)
  - **Section 3**: Bar chart — Impact Score per domain
  - **Section 4**: Scatter — Traffic vs Conversion Rate (colored by cluster)
  - **Section 5**: What-If Simulator
    - Select domain from dropdown
    - Sliders: adjust conversion_rate delta, error_rate delta
    - Show predicted new score + revenue impact
  - **Footer**: Download recommendations as CSV
- [ ] Test all interactions locally
- [ ] Add `st.cache_data` to all heavy computations

### Deliverable
`streamlit run src/dashboard/app.py` — full working dashboard on localhost.

---

## Phase 6 — Polish & Deploy (Day 7)

### Goals
- Final testing, CI/CD pipeline, demo prep

### Tasks

- [ ] Write `.gitlab-ci.yml`
  ```yaml
  stages:
    - test
    - deploy

  test:
    script:
      - pip install -r requirements.txt
      - python -m pytest tests/

  deploy:
    script:
      - streamlit run src/dashboard/app.py &
  ```
- [ ] Run all unit tests — fix any failures
- [ ] Record 2-minute demo video or prepare live demo
- [ ] Update `README.md` with setup steps and screenshots
- [ ] Final resume bullet (already added):
  > *Built Domain Forge AI — an ML pipeline using K-Means, Random Forest, and LSTM to score and prioritize website domains for redesign based on business impact.*

### Deliverable
Deployed app + passing CI pipeline + demo ready.

---

## Risk & Mitigation

| Risk | Mitigation |
|---|---|
| No real GA data available | Use generated sample CSV with realistic distributions |
| LSTM too slow to train | Use Random Forest only for MVP; LSTM as stretch goal |
| Streamlit layout breaks | Test each section incrementally, not all at once |
| GitLab CI errors | Test pipeline locally with `gitlab-runner` or skip CI for demo |

---

## MVP Scope (Non-Negotiables)

These must work for a complete demo:

1. Data loads from CSV
2. Domains are clustered into 3 segments
3. Impact Score computed per domain
4. Priority ranking displayed (HIGH/MEDIUM/LOW)
5. Streamlit dashboard runs locally

Everything else (LSTM, CI/CD, what-if simulation) is a stretch goal.

---

## Success Criteria

- [ ] All 5 MVP items above work end-to-end
- [ ] Dashboard renders without errors on a fresh machine
- [ ] At least 1 unit test passes
- [ ] Code is clean, commented, and committed to GitLab
