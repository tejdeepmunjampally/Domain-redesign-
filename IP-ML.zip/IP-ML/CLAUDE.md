# CLAUDE.md — Domain Forge AI

## Project Overview

**Domain Forge AI** is a machine learning-powered decision system that analyzes user behavior and business metrics to intelligently prioritize website domains and subdomains for redesign based on their impact on revenue and user retention.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend / Dashboard | Streamlit |
| ML Models | Scikit-learn (Random Forest, K-Means), TensorFlow/Keras (LSTM) |
| Data Processing | Pandas, NumPy |
| Visualization | Plotly, Matplotlib |
| CI/CD | GitLab CI/CD |
| Language | Python 3.10+ |

---

## Project Structure

```
domain-forge-ai/
├── data/
│   ├── raw/                  # Raw input CSVs (analytics, logs)
│   ├── processed/            # Cleaned, normalized datasets
│   └── sample/               # Sample data for testing
│
├── src/
│   ├── ingestion/
│   │   └── data_loader.py    # Load from GA, logs, CSVs
│   ├── preprocessing/
│   │   └── cleaner.py        # Null handling, normalization, encoding
│   ├── analysis/
│   │   └── journey.py        # User journey path builder
│   ├── models/
│   │   ├── clustering.py     # K-Means segmentation
│   │   ├── predictor.py      # Random Forest + LSTM models
│   │   └── scorer.py         # Domain Impact Score engine
│   ├── recommendation/
│   │   └── ranker.py         # Priority ranking + what-if simulation
│   └── dashboard/
│       └── app.py            # Streamlit dashboard
│
├── notebooks/
│   └── exploration.ipynb     # EDA and model experiments
│
├── tests/
│   └── test_scorer.py        # Unit tests
│
├── .gitlab-ci.yml            # CI/CD pipeline config
├── requirements.txt
├── CLAUDE.md                 # ← this file
└── plan.md                   # Project execution plan
```

---

## Key Modules

### 1. `data_loader.py`
- Reads from CSV exports (Google Analytics, server logs)
- Produces a unified DataFrame with columns: `domain`, `traffic`, `conversion_rate`, `bounce_rate`, `ltv`, `error_rate`

### 2. `cleaner.py`
- Drops nulls, normalizes all numeric columns to [0, 1]
- Encodes user journey sequences for LSTM input

### 3. `journey.py`
- Reconstructs per-session user paths across domains
- Identifies drop-off points and conversion paths

### 4. `clustering.py`
- Applies K-Means (k=3) to segment users: High-Value, Drop-Off, Low-Value
- Outputs cluster labels appended to the main DataFrame

### 5. `predictor.py`
- **Random Forest**: predicts conversion probability and churn risk per domain
- **LSTM**: predicts future performance from sequential visit data

### 6. `scorer.py`
- Computes `Domain Impact Score`:
  ```
  score = w1*traffic + w2*conversion_rate + w3*ltv - w4*churn_risk - w5*error_rate
  ```
- Weights are configurable via `config.yaml`

### 7. `ranker.py`
- Sorts domains into: `HIGH`, `MEDIUM`, `LOW` priority
- Simulates "what-if redesign" outcomes using model predictions

### 8. `app.py` (Streamlit)
- Displays ranked domain table
- Interactive bar charts, scatter plots
- What-if simulation sliders
- CSV export of recommendations

---

## Environment Setup

```bash
git clone <repo-url>
cd domain-forge-ai
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run src/dashboard/app.py
```

---

## Configuration

All model weights and thresholds live in `config.yaml`:

```yaml
impact_score:
  weights:
    traffic: 0.2
    conversion_rate: 0.35
    ltv: 0.25
    churn_risk: 0.1
    error_rate: 0.1

clustering:
  k: 3
  random_state: 42

priority_thresholds:
  high: 0.7
  medium: 0.4
```

---

## ML Pipeline Summary

```
Raw Data → Preprocessing → Journey Analysis
    → K-Means Clustering → RF + LSTM Prediction
    → Impact Score → Ranked Recommendations → Dashboard
```

---

## Coding Conventions

- All functions must have docstrings
- Use type hints throughout
- Data must never be mutated in-place — always return a new DataFrame
- Model artifacts saved to `models/saved/` as `.pkl` or `.h5`
- No hardcoded paths — use `pathlib.Path` and `config.yaml`

---

## Sample Domain Impact Score Output

| Domain | Traffic | Conv. Rate | LTV | Churn Risk | Score | Priority |
|---|---|---|---|---|---|---|
| shop.example.com | High | Low | High | High | 0.81 | HIGH |
| blog.example.com | Medium | Medium | Low | Low | 0.53 | MEDIUM |
| docs.example.com | Low | High | Medium | Low | 0.44 | MEDIUM |
| old.example.com | Low | Low | Low | High | 0.21 | LOW |

---

## Authors

- **Team Paradise** — Vignan Institute of Technology and Science
- Project developed for ideathon/hackathon competition context
